@extends('layouts.main')

@section('content')
<div class="wrapper">
    @if(!empty($shows))
    @foreach($shows as $show)
    <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2">
        <div class="panel panel-theme">
            <div class="panel-heading">
                <h3 class="panel-title">{{ $show->title }} <span style="float: right"><a style="text-decoration: none; color: #fff" href="{{ route('order', ['show_id' => $show->id]) }}">Ticket <i class="glyphicon glyphicon-shopping-cart"></i></a></span></h3>
            </div>
            <div class="panel-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xs-12 col-lg-9 col-md-9 col-sm-9">
                            <p>{{ $show->description }}</p>
                        </div>
                        <div class="hidden-xs col-lg-3 col-md-3 col-sm-3">
                            <img src="{{ $show->image }}" style="float: right; height: auto; width: 100%; margin: auto" alt="Image">
                        </div>
                    </div>
                    <p><strong>Price: €</strong>{{ $show->price }}</p>
                </div>
            </div>
        </div>
    </div>
    @endforeach
    @else
    <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2">
        <div class="panel panel-theme">
            <div class="panel-heading">
                <h3 class="panel-title">No Shows</h3>
            </div>
            <div class="panel-body">
                <div class="container-fluid">
                    <p>There are no shows.</p>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>
@endsection
