@extends('layouts.main')

@section('content')
<div class="wrapper">
    <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2">
        <div class="panel panel-theme news">
            <div class="panel-heading">
                <h3 class="panel-title">{{ \App\Color\MinecraftColor::stripColor($name) }}</h3>
            </div>
            <div class="panel-body">
                <div class="col-lg-6 col-xs-12 col-md-6 col-sm-12">
                    <p>Personal: {{ $personal }}</p>
                    <p>Total: {{ $total }}</p>
                </div>
                <div class="col-lg-6 col-xs-12 col-md-6 col-sm-12">
                    @if(!empty($top10))
                    @foreach($top10 as $row)
                    @php($username = \App\Cache\Cache::getUsername($row->uuid))
                    @if($username !== $row->uuid)
                    <p><b>{{ $row->num }}#</b> {{ $username }}<b>:</b> {{ $row->count }}</p>
                    @endif
                    @endforeach
                    @else
                    <p>Nobody has ridden this attraction this week</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
