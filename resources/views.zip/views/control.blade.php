@extends('layouts.main')

@section('content')
    <div class="container-fluid" style="margin-top: 75px">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                <div class="panel panel-theme">
                    <div class="panel-heading">
                        <h3 class="panel-title">Information</h3>
                    </div>
                    <div class="panel-body">
                        <div class="col-xs-12" style="margin-bottom: 5px">
                            <img class="center-block" src="{{ Auth::user()->photo() }}">
                        </div>
                        <p><strong>Username:</strong> {{ Auth::user()->username() }}
                            <br><strong>Attraction:</strong> {{ $attraction_name }}</p>
                        <p><strong>Control:</strong> <span id="control" class="control-status status-closed">Disconnected</span></p>
                        <p><strong>Status:</strong> <span id="status" class="control-status status-unknown">Unknown</span></p>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-8 col-lg-9">
                <div id="message" class="col-xs-12"></div>
                <div id="panel" class="col-xs-12" style="margin: 0; padding: 0">
                </div>
            </div>
        </div>
    </div>
@endsection

@section('javascript')
<script>
window.settings = {
    id: '{{ env('CONTROL_ID', 'themepark') }}',
    uuid: '{{ Auth::user()->uuid }}',
    attraction: '{{ $attraction_id }}',
    pin: '{{ $pin }}'
};
</script>
<script src="{{ asset('assets/js/control.js') }}"></script>
@endsection
