@extends('layouts.profile')

@section('content')
<div class="container-fluid" style="margin-top: 75px">
    @if(Auth::user()->hasShows())
    @foreach(Auth::user()->getShows() as $show)
    <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2">
        <div class="panel panel-theme">
            <div class="panel-heading">
                <h3 class="panel-title">{{ $show->title }}</h3>
            </div>
            <div class="panel-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xs-12 col-lg-9 col-md-9 col-sm-9">
                            <p>{!! $show->description !!}</p>
                            @php($time = strtotime($show->date))
                            <p class="bottom"><strong>Date: </strong>{{ date('d-m-Y', $time) }} at {{ date('H:m', $time) }}</p>
                            <p><strong>Seat: </strong>{{ $show->seat }}</p>
                            <p><strong>Voucher: </strong>{{ $show->voucher }}</p>
                        </div>
                        <div class="hidden-xs col-lg-3 col-md-3 col-sm-3">
                            <img src="{{ $show->image }}" style="float: right; height: auto; width: 100%; margin: auto" alt="Image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endforeach
    @else
    <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2">
        <div class="panel panel-theme">
            <div class="panel-heading">
                <h3 class="panel-title">No Shows</h3>
            </div>
            <div class="panel-body">
                <div class="container-fluid">
                    <p>You have no tickets for shows.</p>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>
@endsection
