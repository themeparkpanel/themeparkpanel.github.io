<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <!-- ==============================================
		            Title and Meta Tags
	=============================================== -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'ThemePark') }}</title>

    <!-- ==============================================
                         CSS Files
    =============================================== -->
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/panel.min.css') }}" rel="stylesheet">
</head>
<body>

<div class="page">
    <div class="form">
        <form method="post" action="{{ route('2fa.authenticate') }}">
            @csrf
            <h2 class="text-center">ThemePark</h2>

            <div class="form-group @error('two_factor') has-error @enderror">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                    <input id="two_factor" type="text" class="form-control" name="two_factor" required autocomplete="off" autofocus>
                </div>
                @error('two_factor')
                <span class="help-block" style="font-size: 12px">{{ $message }}</span>
                @enderror
            </div>

            <button class="btn btn-custom" style="width: 100%">{{ __('Authenticate') }}</button>
            <a class="btn btn-link" href="{{ route('logout') }}">{{ __('Logout') }}</a>
        </form>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <span>Copyright &copy; 2019-{{ date('Y') }} <a href="https://www.iobyte.nl/"><img src="{{ asset('assets/img/logo-lg.png') }}" alt="IOByte" style="height: 20px"></a>. All Rights Reserved.</span>
    </div>
</footer>

<!-- ==============================================
                      JS Files
=============================================== -->
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
</body>
</html>


@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('2FA Authenticate') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('2fa.authenticate') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="two_factor" class="col-md-2 offset-md-3 col-form-label text-md-right">{{ __('2FA Code') }}</label>

                            <div class="col-md-4">
                                <input id="two_factor" type="text" class="form-control @error('two_factor') is-invalid @enderror" name="two_factor" required autocomplete="two_factor" autofocus>

                                @error('two_factor')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-3">
                                <button type="submit" class="btn btn-block btn-primary">
                                    {{ __('Authenticate') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
