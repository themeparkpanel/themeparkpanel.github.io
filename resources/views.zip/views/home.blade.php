@extends('layouts.main')

@section('content')
<div class="container-fluid" style="margin-top: 75px">
    <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2">
        @php($message = \App\Message::orderByDesc('id')->first())
        @if(!empty($message))
        <div class="panel panel-theme news">
            <div class="panel-heading">
                @php($time = strtotime($message->created_at))
                <h3 class="panel-title">{{ \App\Cache\Cache::getUsername($message->uuid) }}<span style="float: right">{{ date('d-m-Y', $time) }} at {{ date('H:m', $time) }}</span></h3>
            </div>
            <div class="panel-body">
                <div class="container-fluid">
                    {!! $message->content !!}
                </div>
            </div>
        </div>
        @endif
    </div>
</div>
@endsection
