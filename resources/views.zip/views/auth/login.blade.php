<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <!-- ==============================================
		            Title and Meta Tags
	=============================================== -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- ==============================================
                         CSS Files
    =============================================== -->
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/panel.min.css') }}" rel="stylesheet">
</head>
<body>

<div class="page">
    <div class="form">
        <form method="post" action="{{ route('login') }}">
            @csrf
            <h2 class="text-center">ThemePark</h2>
            @if($errors->any())

                <div class="alert alert-danger" role="alert">
                    {{ __('Invalid Username or Password') }}
                    <a class="close" data-dismiss="alert" aria-label="close">&times;</a>
                </div>

            @endif
            <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                <input id="uuid" type="text" class="form-control" name="uuid" value="{{ old('username') }}" placeholder="Username" required autocomplete="username" autofocus>
            </div>
            <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                <input id="password" type="password" class="form-control" name="password" placeholder="Password" required autocomplete="current-password">
            </div>

            <button class="btn btn-custom" style="width: 100%">{{ __('Login') }}</button>
            <p>No account yet, <a href="{{ route('register') }}">{{ __('Register one') }} </a>or,
            <br>Did you <a href="{{ route('password.request') }}">{{ __('forget your password') }}</a>?</p>
        </form>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <span>Copyright &copy; 2019-{{ date('Y') }} <a href="https://www.iobyte.nl/"><img src="{{ asset('assets/img/logo-lg.png') }}" alt="IOByte" style="height: 20px"></a>. All Rights Reserved.</span>
    </div>
</footer>

<!-- ==============================================
                      JS Files
=============================================== -->
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
</body>
</html>
