<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <!-- ==============================================
		            Title and Meta Tags
	=============================================== -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- ==============================================
                         CSS Files
    =============================================== -->
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/panel.min.css') }}" rel="stylesheet">
</head>
<body>

<div class="page">
    <div class="form">
        <form method="post" action="{{ route('register') }}">
            @csrf
            <h2 class="text-center">ThemePark</h2>
            @if($errors->any())

            <div class="alert alert-danger" role="alert">
                {{ __($errors->first()) }}
                <a class="close" data-dismiss="alert" aria-label="close">&times;</a>
            </div>

            @endif
            <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                <input id="username" type="text" class="form-control" name="username" value="{{ old('username') }}" placeholder="Username" required autocomplete="username" autofocus>
            </div>

            <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" placeholder="Email" required autocomplete="email" autofocus>
            </div>

            <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                <input id="password" type="password" class="form-control" name="password" placeholder="Password" required autocomplete="off">
            </div>

            <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                <input id="password_confirmation" type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password" required autocomplete="off">
            </div>

            <button class="btn btn-custom" style="width: 100%">{{ __('Register') }}</button>
            <p>Already have an account, <a href="{{ route('login') }}">{{ __('Login') }} </a></p>
        </form>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <span>Copyright &copy; 2019-{{ date('Y') }} <a href="https://www.iobyte.nl/"><img src="{{ asset('assets/img/logo-lg.png') }}" alt="IOByte" style="height: 20px"></a>. All Rights Reserved.</span>
    </div>
</footer>

<!-- ==============================================
                      JS Files
=============================================== -->
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
<script>
window.onload = function() {
    const passInput = document.getElementById('password_confirmation');
    passInput.onpaste = function (e) {
        e.preventDefault();
    };
};
</script>
</body>
</html>
