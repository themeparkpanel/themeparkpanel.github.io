@extends('layouts.main')

@section('content')
<div class="container-fluid" style="margin-top: 75px">
    <div class="col-xs-12 col-md-8 col-md-offset-2">
        <div class="panel panel-theme news">
            <div class="panel-heading">
                <h3 class="panel-title">OpenAudioMC</h3>
            </div>
            <div class="panel-body">
                @if($type === 1)
                <p>Welcome to the audio client page!
                    <br><br>Unfortunately, this server hasn't linked their OpenAudioMc account to the panel yet, but when they do, this page will re-direct you to your web client so you can open it from here with your personal login token.
                    To get started, login to OpenAudioMc+ using `/oa plus`, go to the "API" tab (as seen in the left side of the page) and copy the url labeled "V1 - Get Token" and paste it into the .env file. Remember to change <strong>"&lt;PLAYER UUID&gt;"</strong> into <strong>"%UUID%"</strong> for correct installation.</p>
                @elseif($type=== 2)
                <p>Hey there {{ Auth::user()->username() }}!
                    <br><br>You aren't online in the server right now and thus can't connect to the audio client. Please login or try again in a few seconds.</p>
                @else
                <p>You seem to already have an open session with the audio client. You may dismiss this page since you are already connected or try again in a few seconds if you have closed it recently.</p>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
